package com.example.asm_and103_ph45538.AccountActivity;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.asm_and103_ph45538.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class DangKiActivity extends AppCompatActivity {
EditText edt_name,edt_email_rgt,edt_pass_rgt,edt_repass;
Button btn_register;
TextView txt_click;
    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dang_ki);
        mAuth=FirebaseAuth.getInstance();
        edt_name=findViewById(R.id.edt_name);
        edt_email_rgt=findViewById(R.id.edt_email_rgt);
        edt_pass_rgt=findViewById(R.id.edt_pass_rgt);
        edt_repass=findViewById(R.id.edt_repass);
        btn_register=findViewById(R.id.btn_register);
        txt_click=findViewById(R.id.txt_click);

        txt_click.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(DangKiActivity.this, ManDangNhapActivity.class));
            }
        });


        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createAccount(edt_email_rgt.getText().toString(), edt_pass_rgt.getText().toString());
            }
        });
    }

    private void createAccount(String email, String password) {
        Log.d(TAG, "createAccount:" + email);
        if (!validateForm()) {
            return;
        }

        // Create user with email and password
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d(TAG, "createUserWithEmail:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            updateUI(user);
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w(TAG, "createUserWithEmail:failure", task.getException());
                            Toast.makeText(DangKiActivity.this, "Authentication failed.",
                                    Toast.LENGTH_SHORT).show();
                            updateUI(null);
                        }
                    }
                });
    }

    private boolean validateForm() {
        boolean valid = true;

        String email = edt_email_rgt.getText().toString();
        if (TextUtils.isEmpty(email)) {
            edt_email_rgt.setError("Required.");
            valid = false;
        } else {
            edt_email_rgt.setError(null);
        }



        String password = edt_pass_rgt.getText().toString();
        if (TextUtils.isEmpty(password)) {
            edt_pass_rgt.setError("Required.");
            valid = false;
        } else {
            edt_pass_rgt.setError(null);
        }

        return valid;
    }

    private void updateUI(FirebaseUser user) {
        if (user != null) {
            // Navigate to another activity or update the current UI
            Toast.makeText(DangKiActivity.this, "Registration successful!", Toast.LENGTH_SHORT).show();
        } else {
            // Handle registration failure
            Toast.makeText(DangKiActivity.this, "Registration failed.", Toast.LENGTH_SHORT).show();
        }
    }

}