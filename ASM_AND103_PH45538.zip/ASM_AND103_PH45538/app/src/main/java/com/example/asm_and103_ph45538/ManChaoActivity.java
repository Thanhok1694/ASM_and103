package com.example.asm_and103_ph45538;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import com.example.asm_and103_ph45538.AccountActivity.ManDangNhapActivity;

public class ManChaoActivity extends AppCompatActivity {
ImageView img_loading;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_man_chao);
        img_loading=findViewById(R.id.img_loading);
        Animation rotateAnimation = AnimationUtils.loadAnimation(this, R.anim.ani);
        img_loading.startAnimation(rotateAnimation);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent it=new Intent(ManChaoActivity.this, ManDangNhapActivity.class);
                startActivity(it);
                finish();
            }
        },3000);
    }
}