const express = require('express');
const router = express.Router();
const Product = require('./ProductModel');

// Route để lấy tất cả sản phẩm
router.get('/', async (req, res) => {
  try {
    console.log('Fetching products...');
    const products = await Product.find();
    console.log('Products fetched:', products);
    res.json(products);
  } catch (err) {
    console.error('Error fetching products:', err);
    res.status(500).json({ message: err.message });
  }
});

// Route để tìm kiếm sản phẩm theo tên
router.get('asm/products/search', async (req, res) => {
  const { name } = req.query;
  try {
    console.log(`Searching products by name: ${name}`);
    const products = await Product.find({ name: { $regex: name, $options: 'i' } });
    console.log('Products found:', products);
    res.json(products);
  } catch (err) {
    console.error('Error searching products:', err);
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
