const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const productRoutes = require('./ProductRoute');

const app = express();
const port = 3000;

// Kết nối đến MongoDB mà không sử dụng useNewUrlParser và useUnifiedTopology
mongoose.connect('mongodb+srv://ducthanh16904:thanhok169@cluster0.vmynve9.mongodb.net/asm',{
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function () {
  console.log('Connected to MongoDB');
});

// Middleware
app.use(bodyParser.json());
app.use('/asm/products', productRoutes);

// Bắt đầu server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
